<?php
define('SERVER',"localhost");
define('USER',"root");
define('PASSWORD',"");
define('DATABASE','tallyworld');
?>