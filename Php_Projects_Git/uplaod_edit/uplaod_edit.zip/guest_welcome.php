<?php
session_start();
//if(isset($_SESSION['admin']))
if(isset($_SESSION['admin']) || isset($_SESSION['guest']))
{
    include ('sudo_header.php');
    include('blogic.php');
    $ob = new blogic();
    $queryPlayerDetails="SELECT * FROM tally_bidders";
    $playerResultSet = $ob-> fetch_values($queryPlayerDetails);
    if ($playerResultSet == true || $playerResultSet != null)
        {
            
?>
<fieldset>
<legend>Bidder Selection : </legend>
<form id="myForm" action="match_calc_result.php" name="myForm" method="post" onsubmit="return match_details_validate();" >
<table class="match-details">
<tr>
<td >Please Select Bidder :</td>
<td>
                            <select name="bidderName" id="bidderName"  >
                            <option value="select" >-----------------Select-----------------</option>
                            <?php 
                            while($row = mysql_fetch_array($playerResultSet))
                                {
	                           echo '<option value="'. $row['bidder_id'] . '">'. $row['bidder_name']  . '</option>';
                                }
                           ?>
                            

</td>
</tr>
<tr>
<td></td>
<td>
<input class="styled-button-1" type="submit" name="submit_bidder" value="Submit" />
</td></tr>
<?php            
        }
}
else
{

   echo '<script>alert("Please Login to see the details...!!!"); window.location = "index.php"</script>';
}
?>