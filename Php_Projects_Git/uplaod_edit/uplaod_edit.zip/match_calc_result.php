<?php
include('blogic.php');
$ob = new blogic();
session_start();
if(isset($_SESSION['admin']) || isset($_SESSION['guest']))
{
include ('sudo_header.php');
 if(isset($_POST['submit_bidder']))
 
    {
        $bidderName=$_POST['bidderName'];
    
$calculateQuery="SELECT tnt.tally_net_amt,tb.bidder_name,tnt.tally_net_tranc_mdate, tmd.tally_team1, tmd.tally_team2,tmd.tally_match_winner_team,ttd.tally_team_name FROM tally_bidders tb 
INNER JOIN tally_net_transaction tnt ON tb.bidder_id=tnt.tally_net_bidder_name
INNER JOIN tally_match_details tmd ON tmd.match_details_id=tnt.tally_net_match_details_id_fk
INNER JOIN tally_transaction_details ttd ON ttd.tally_transc_id=tnt.tally_net_transc_details_id_fk
WHERE tb.bidder_id=$bidderName";
$bidderNetTransactionList = $ob-> fetch_values($calculateQuery);
    }
else
    {
      echo '<script>alert("Please Select a bidder...!!!"); window.location = "guest_welcome.php"</script>';  
    }
if ($bidderNetTransactionList == true || $bidderNetTransactionList != null)
  {
    
?>
<fieldset>
<legend>Bidder Tally : </legend>

<table class="match-details">
<tr><th >S.No</th><th>Bidder's Name</th><th>Bidding Date</th><th>Match Detail</th><th>Winning Team</th><th>Bidder's Team</th><th>Bidder's Net Amt(Rs.)</th></tr>
<?php   
        $i=1;
        while ($row = mysql_fetch_array($bidderNetTransactionList))
        {
            
            $bidderName = $row['bidder_name'];
            $tally_net_amt = $row['tally_net_amt'];
            $tally_net_tranc_mdate= $row['tally_net_tranc_mdate'];
            $tally_team1= $row['tally_team1'];
            $tally_team2= $row['tally_team2'];
            $tally_match_winner_team= $row['tally_match_winner_team'];
            $bidders_team_name= $row['tally_team_name'];
            //$matchdate= $row['tally_match_date'];

?>

<tr><td><?php echo $i; ?> </td><td><?php echo $bidderName; ?></td><td><?php echo $tally_net_tranc_mdate; ?></td><td><?php echo $tally_team1; ?>&nbsp;vs&nbsp;<?php echo $tally_team2; ?></td>
<td><?php echo $tally_match_winner_team;  ?></td><td><?php echo $bidders_team_name;  ?></td><td><?php echo $tally_net_amt;?></td>
<?php
            $i++; 
        } 
    }
?>
</table>
</fieldset>
<?php
}
else
{
   echo '<script>alert("Please Login to see the details...!!!"); window.location = "index.php"</script>';
}
?>