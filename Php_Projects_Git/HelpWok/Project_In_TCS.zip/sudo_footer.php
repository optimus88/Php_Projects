<?php
?>
	</div>
		</div>
		</div>

			<div class="feature">
				<p>Click <a href="sudo_generate_result.php?report_query=<?php echo $query; ?>">HERE</a>  to generate <i>"Deployment Tracker"<i/> report.</p>
                
			</div>
	</div>
</body>
</html>
