<?php  
include ('sudo_header.php');
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="gencyolcu" />

	<title>Untitled 2</title>
</head>

<body>

<a href="welcome.php"><img src="error_img.jpg" height="350" width="400"  /></a>

</body>
</html>