<?php

?>

<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="gencyolcu" />
    <script type="text/javascript" src="javascript/validate.js"></script> 
    <link href="new_style.css" rel="stylesheet" type="text/css" />
	<title style="font-family: Monotype Corsiva;">SWB-Deployment Tracker</title>
</head>

<body>

<div>
	<div class="siteinfo">
		<h1 style="font-family: Monotype Corsiva;">SWB-Deployment Tracker</h1>

                <div class="columns">
		<div class="column4">
			<div class="feature">