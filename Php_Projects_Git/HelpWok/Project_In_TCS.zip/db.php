<?php
define('SERVER',"sql212.byethost17.com");
define('USER',"b17_14312762");
define('PASSWORD',"keshav");
define('DATABASE','b17_14312762_deployment_tracker');
?>