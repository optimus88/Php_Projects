<?php
?>
	</div>
		</div>
		</div>

			<div class="feature">
				
               
                    <p>Forgot Password ? Please <a href="forgot_password.php">"Click" </a>here...!!!!</p>
               
                
                 
			</div>
	</div>
</body>
</html>
